Don't forget to download or make build packages!
You can download them in the following locations:
https://magmaguy.itch.io/
https://www.patreon.com/magmaguy