// This file is retired : settings now can be tailored using url section in configuration.txt, when needed
//