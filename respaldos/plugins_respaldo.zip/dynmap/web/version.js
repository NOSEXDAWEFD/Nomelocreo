var dynmapversion = "3.7-beta-5-943";

